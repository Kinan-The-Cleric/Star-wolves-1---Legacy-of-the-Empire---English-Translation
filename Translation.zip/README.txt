Instructions to install the mod, then the english data (Skip step 1 and 3 if you already installed the mod on russian language):
1_after installing the mod in a separate folder, go to DATA folder in star wolves 1 exe location.
2_rename Data.dat to Data.zip
3_copy 'Data' from the mod folder inside the zip file

Now you have the russian version for the mod. To modify the english language:
4_navigate to Data.zip\Data\LocData
5_copy the 'English' folder you downloaded from my repository and paste it in this folder, this will overwrite all the data that needs to
be modified.
6_Close the zip file and rename it back to Data.dat

=======================================================================================================================================

Link to where I got the mod:
https://steamcommunity.com/app/46270/discussions/0/828934913160346773/?l=german

Additional tips to avoid crashing/bugs:
-run the game as administrator (prevents stuck projectiles)
-When loading games saved during a mission, scripts sometimes do not work. To get around this problem, load a game save between 
missions (Intermission System).
-When playing the game, try to follow the instructions (quests), deviating from them will often stop the action
-When entering a map, sometimes you have to refrain from moving the mothership until the encounter is over (Like in 'Secrets of Inoco'
and 'Golden Castle' after leaving the precursor portal)
-If all methods fail, try to follow this youtube video's steps accurately:
https://www.youtube.com/watch?v=zygSCcTq05Q&

=======================================================================================================================================

Special thanks to the creators of this mod, whom you'll find in ReadMe-EG.txt in the mod's folder. And thanks to Fredel (Fred777 on GoG) 
who created the cipher tool that helped me encode/decode in-game dialogs