This is a reupload of the mod since the download link doesn't work anymore on elite-games.ru website
If you are a developer or publisher of this mod and have a problem with me reuploading it, please message me and I'll delete it right away!
